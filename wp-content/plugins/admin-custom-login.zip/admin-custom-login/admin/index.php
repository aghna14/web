<?php
defined( 'ABSPATH' ) or die();
require_once WEBLIZAR_ACL_PLUGIN_DIR_PATH_FREE . '/admin/WL_ACL_FREE_Menu.php';
?>
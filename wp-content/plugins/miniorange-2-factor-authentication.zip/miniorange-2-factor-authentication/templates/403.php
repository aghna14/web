<?php header('HTTP/1.0 403 Forbidden');?>
<h1>403 Forbidden</h1>
You don't have permission to access this website.<br><br>
<hr>

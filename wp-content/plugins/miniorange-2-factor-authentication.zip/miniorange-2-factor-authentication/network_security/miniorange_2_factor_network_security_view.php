<?php

include_once dirname( __FILE__ ) . '/views/miniorange_network_security_monitoring.php';
include_once dirname( __FILE__ ) . '/views/miniorange_network_security_ip_blocking.php';
include_once dirname( __FILE__ ) . '/views/miniorange_network_security_brute_force.php';
include_once dirname( __FILE__ ) . '/views/miniorange_network_security_strong_password.php';
include_once dirname( __FILE__ ) . '/views/miniorange_network_security_content_protection.php';
?>